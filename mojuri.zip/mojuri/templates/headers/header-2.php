	<?php 
		$mojuri_settings = mojuri_global_settings();
		$cart_layout = mojuri_get_config('cart-layout','dropdown');
		$cart_style = mojuri_get_config('cart-style','light');
		$show_minicart = (isset($mojuri_settings['show-minicart']) && $mojuri_settings['show-minicart']) ? ($mojuri_settings['show-minicart']) : false;
		$show_compare = (isset($mojuri_settings['show-compare']) && $mojuri_settings['show-compare']) ? ($mojuri_settings['show-compare']) : false;
		$enable_sticky_header = ( isset($mojuri_settings['enable-sticky-header']) && $mojuri_settings['enable-sticky-header'] ) ? ($mojuri_settings['enable-sticky-header']) : false;
		$show_searchform = (isset($mojuri_settings['show-searchform']) && $mojuri_settings['show-searchform']) ? ($mojuri_settings['show-searchform']) : false;
		$show_wishlist = (isset($mojuri_settings['show-wishlist']) && $mojuri_settings['show-wishlist']) ? ($mojuri_settings['show-wishlist']) : false;
		$show_currency = (isset($mojuri_settings['show-currency']) && $mojuri_settings['show-currency']) ? ($mojuri_settings['show-currency']) : false;
		$show_menutop = (isset($mojuri_settings['show-menutop']) && $mojuri_settings['show-menutop']) ? ($mojuri_settings['show-menutop']) : false;
	?>
	<h1 class="bwp-title hide"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
	<header id='bwp-header' class="bwp-header header-v2">
		<?php mojuri_campbar(); ?>
		<?php mojuri_menu_mobile(); ?>
		<div class="header-desktop">
			<?php if(($show_minicart || $show_wishlist || $show_searchform || is_active_sidebar('top-link')) && class_exists( 'WooCommerce' ) ){ ?>
			<div class='header-wrapper' data-sticky_header="<?php echo esc_attr($mojuri_settings['enable-sticky-header']); ?>">
				<div class="container">
					<div class="row">
						<div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 col-12 header-left">
							<!-- Begin Search -->
								<?php if($mojuri_settings['show-searchform']){ ?>
								<div class="search-box search-dropdown">
									<div class="search-toggle search-toggle-2"><i class="icon-search"></i></div>
									<div class="dropdown-search"><?php get_template_part( 'search-form' ); ?></div>
								</div>
								<?php } ?>
							<!-- End Search -->
						</div>
						<div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 header-center content-header">
							<div class="wpbingo-menu-mobile header-menu hidden-lg hidden-md">
								<div class="header-menu-bg">
									<?php mojuri_top_menu(); ?>
								</div>
							</div>
							<div class="header-menu-left wpbingo-menu-mobile header-menu">
								<div class="header-menu-bg">
									<?php mojuri_top_menu_left(); ?>
								</div>
							</div>
							<?php mojuri_header_logo(); ?>
							<div class="header-menu-right wpbingo-menu-mobile header-menu">
								<div class="header-menu-bg">
									<?php mojuri_top_menu_right(); ?>
								</div>
							</div>
						</div>
						<div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 col-12 header-right">
							<div class="header-page-link">
								<div class="login-header">
									<?php if (is_user_logged_in()) { ?>
										<?php if(is_active_sidebar('top-link')){ ?>
											<div class="block-top-link">
												<?php dynamic_sidebar( 'top-link' ); ?>
											</div>
										<?php } ?>
									<?php }else{ ?>
										<a class="active-login" href="#" ><i class="icon-user"></i></a>
										<?php mojuri_login_form(); ?>
									<?php } ?>
								</div>	
								<?php if($show_wishlist && class_exists( 'WPCleverWoosw' )){ ?>
								<div class="wishlist-box">
									<a href="<?php echo WPcleverWoosw::get_url(); ?>"><i class="icon-heart"></i></a>
									<span class="count-wishlist"><?php echo WPcleverWoosw::get_count(); ?></span>
								</div>
								<?php } ?>
								<?php if($show_minicart && class_exists( 'WooCommerce' )){ ?>
								<div class="mojuri-topcart <?php echo esc_attr($cart_layout); ?> <?php echo esc_attr($cart_style); ?>">
									<?php get_template_part( 'woocommerce/minicart-ajax' ); ?>
								</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div><!-- End header-wrapper -->
			<?php }else{ ?>
				<div class="header-normal">
					<div class='header-wrapper' data-sticky_header="<?php echo esc_attr($mojuri_settings['enable-sticky-header']); ?>">
						<div class="container">
							<div class="row">
								<div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6 header-left">
									<?php mojuri_header_logo(); ?>
								</div>
								<div class="col-xl-9 col-lg-9 col-md-6 col-sm-6 col-6 header-main">
									<div class="header-menu-bg">
										<?php mojuri_top_menu(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</header><!-- End #bwp-header -->