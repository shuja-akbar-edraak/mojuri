<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<p class="woocommerce-info"><?php esc_html_e( 'No posts were found matching your selection.', 'mojuri' ); ?></p>