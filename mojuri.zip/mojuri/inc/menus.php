<?php
    /*
    *
    *	Wpbingo Framework Menu Functions
    *	------------------------------------------------
    *	Wpbingo Framework v3.0
    * 	Copyright Wpbingo Ideas 2017 - http://wpbingosite.com/
    *
    *	mojuri_setup_menus()
    *
    */
    /* CUSTOM MENU SETUP
    ================================================== */
    register_nav_menus( array(
        'main_navigation' 	=> esc_html__( 'Main Menu', 'mojuri' ),
		'topbar_menu'   	=> esc_html__( 'Topbar Menu', 'mojuri' ),
        'menu_left'         => esc_html__( 'Menu Left', 'mojuri' ),
        'menu_right'        => esc_html__( 'Menu Right', 'mojuri' )
    ) );
?>