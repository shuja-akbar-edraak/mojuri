<?php 
	get_header(); 
	$mojuri_settings = mojuri_global_settings();
?>
<div class="page-404">
	<div class="content-page-404">
		<div class="title-error">
			<?php if(isset($mojuri_settings['title-error']) && $mojuri_settings['title-error']){
				echo esc_html($mojuri_settings['title-error']);
			}else{
				echo esc_html__("404", "mojuri");
			}?>
		</div>
		<div class="sub-title">
			<?php if(isset($mojuri_settings['sub-title']) && $mojuri_settings['sub-title']){
				echo esc_html($mojuri_settings['sub-title']);
			}else{
				echo esc_html__("Oops! That page can't be found.", "mojuri");
			}?>
		</div>
		<div class="sub-error">
			<?php if(isset($mojuri_settings['sub-error']) && $mojuri_settings['sub-error']){
				echo esc_html($mojuri_settings['sub-error']);
			}else{
				echo esc_html__("We're really sorry but we can't seem to find the page you were looking for.", "mojuri");
			}?>
		</div>
		<a class="btn" href="<?php echo esc_url( home_url('/') ); ?>">
			<?php if(isset($mojuri_settings['btn-error']) && $mojuri_settings['btn-error']){
				echo esc_html($mojuri_settings['btn-error']);}
			else{
				echo esc_html__("Back The Homepage", "mojuri");
			}?>
		</a>
	</div>
</div>
<?php
get_footer();